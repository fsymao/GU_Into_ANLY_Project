This Document Served as reference of how to read the submssion and how to run the code. 
========================================================
Package Requirement: 
1.apyrori -> for association rule mining
2.imblarn -> for upsampling 
=======================================================
How to Run? 

There is a wrapper script called Group6Part2.sh 
Make sure you switch to the Submission folder called Part2
Then run following command:
"sh Group6Part2.sh"

Additional Notes: 

1. When runs into clustering analysis, there is an option for you to
change the parameters of the clustering methods. You may type in 'n'
to continue. 

2. When runs into association rule mining, you have to type in 'y' to
input the support and confidence. For testing purpose, you may input support of 
0.1 and confidence of 0.5. 


=======================================================
Folder Structure: 

There are altogther 7 Folders in the Part2 Folder:
AssociationRule: Association Rule Mining 
Clustering: Clustering Analysis 
DataCleaning: DataClearning and Freature Engineering Proceedures 
Histogram_Correlation: EDA study 
Hypothesis Testing: T-test, Anova and Linear Regression 
Predictive_Analytics: Logistics Regression, KNN, SVM, Naive Bayers, Decision Tree and Random Forest 
RawData: Raw data being used in this part of the project. 






